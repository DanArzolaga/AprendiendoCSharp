﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_HolaMundo
{   //Nombre: Daniela Arzola García
    //Matricula: 1842239
    //Grupo: 32
    //Fecha: 28 de septiembre del 2019

    class Program
    {
        static void Main(string[] args)
        {/*Elabore un proyecto de consola que muestre el mensaje “Hola Mundo, ¡ahora en C#!”. 
            Al principio del programa agregar comentarios que indiquen quién es el autor del programa,
            y la fecha de elaboración del programa*/

            //Los bloques de codigo se delimitan con llaves {} y que las lineas terminan con ;

            //El WriteLine se usa para escribir texto o cualquier caracter
            Console.WriteLine("\n\tHola Mundo, ¡Ahora en C#!");
            
            //El ReadKey sirve para pausar el codigo y se puede teclear cualquier tecla 

            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadKey();

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tablas_ciclos_anidados
{   //Autor: Daniela Arzola García
    //Matricula: 1842239
    //Fecha: 24 de septiembre del 2019
    class Program
    {
        static void Main(string[] args)
        {
            /*Elabore un proyecto llamado Tablas, que elabore las tablas de multiplicar del 1 al 10. 
             * Cada tabla deberá tener un encabezado “Tabla del x”. 
             * Entre una tabla y otra, debe haber un salto de línea.*/

            //ENTRADA
          
            Console.WriteLine("\n\tTABLAS DE MULTIPLICAR");

            //En esta parte se hace uso del FOR ya que se trata de un ciclo.
            //El primer FOR hace funcion a x tabla.

            //PROCESO
            for (int i=0; i<=10; i++)
            {//Damos a entender de que tabla se trata
                    Console.WriteLine("\n\tTabla del (0)", i);

                //El segundo FOR hace funcion a x elemento.
                for(int j=0; j<=10; j++)
                {
                    //Nos muestra los elementos y su respectivo resultado
                    Console.WriteLine("{0} x {1} = (2)", i, j, (i * j));
                }
            }
            //SALIDA
            Console.WriteLine("----------------------------------------------");
            Console.WriteLine("\n\tPresiona cualquier tecla para terminar...");
            Console.ReadKey();
        }
    }
}

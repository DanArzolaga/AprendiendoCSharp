﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ENTRADA
{
    //Nombre: Daniela Arzola García
    //Matricula: 1842239
    //Grupo: 12
    //Fecha: 28 de septiembre
    class Entrada
    {
        static void Main(string[] args)
        {
            /* Elabore un proyecto llamado Entrada, que declare una variable que reciba un valor; 
             * si el valor puede ser transformado en integer, mostrar la leyenda “Dato entero: x.
             * ¡Muy bien!” o de lo contrario, mostrar “Dato no es entero. Intentar nuevamente.” 
             * Ejecutar proporcionando un entero, un flotante, y una cadena. */


            //Declaración de variables
            string valor;
            int entrada = 0;

            //Entrada de datos
            Console.WriteLine("Escriba lo que sea: ");
            valor = Console.ReadLine();

            //Condicion en donde al ingresa un numero entero muestra un mensaje
            if (int.TryParse(valor, out entrada))
            {
                Console.WriteLine(string.Format("\n\tDato entero: {0}. ¡Muy Bien!", entrada));

            }
            //En cambio, si no cumple la condición muestra que es incorrecto
            else
            {
                Console.WriteLine("\n\tDato no es entero. Intentar Nuevamente");
            }
            //SALIDA
            Console.WriteLine("\n\tPresiona cualquier tecla para terminar....");
            Console.ReadKey();
        }
    }
}

﻿//Nombre: Daniela Arzola García
//Matricula: 1842239
//Grupo: 32
//Fecha: 28/09/2019
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conversiones
{
    class Program
    {/*Elabore un proyecto de consola llamado Conversiones, que declare una variable
        de tipo string con un valor de “1234”, y que muestre el data type de la variable: 
        realizar la conversión del dato a int, y mostrar el nueva data type. 
        Mostrar también el número que se convirtió.  */
        static void Main(string[] args)
        {
            //Declaramos las variables con su respectivo tipo de dato
            string numero = "1234";

            //El comendo GetType nos muestra la representacion del tipo string de la variable
            Console.WriteLine(numero.GetType().ToString());

            //Declaramos una variable para convertirla en Int y mostrarla en pantalla
            int intNumero = Convert.ToInt32(numero);
            Console.WriteLine(intNumero.GetType().ToString());

            //El comendo String.Formate permite hacer macro substituciones
            Console.WriteLine(String.Format("\n\tEl numero es {0}", intNumero));

            //SALIDA
            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadLine();
        }
    }
}


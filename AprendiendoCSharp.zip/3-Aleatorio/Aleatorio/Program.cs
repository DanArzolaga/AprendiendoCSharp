﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aleatorio
{
    //Nombre: Daniela Arzola García
    //Matricula: 1842239
    //Grupo: 32
    //Fecha: 28 de septiembre
    class Aleatorio
    {/*Elabore un proyecto de consola llamado Aleatorio, que declare una variable a nivel clase, 
        de tipo float, asignándole un valor cualquiera, explícitamente float; en el entry point, 
        declare una variable local de tipo float, que adquiera un valor aleatorio entre 1 y 10, 
        y que muestre en consola el resultado de la suma de las dos variables, 
        usando el mensaje “La suma de x y y es z”. */

        //Esto es para no confundirlo con otra variable
        static public float num1 = 18F;
        static void Main(string[] args)
        {
            /*Aqui declaramos una variable tipo float 
            mostrando el mensaje "La suma de x y y es z"
            Un dato tipo Float nos permite declarar numeros reales de coma flotante*/

            //Declaramos el segundo valor 
            float num2 = 0.0F;

            //Declaramos la instrucción del numero aleatorio
            Random numAle = new Random();

            //Aqui se suma el primer numero con uno aleatorio del 1 al 10
            num2 = (float)numAle.Next(1, 11);

            //SALIDA
            Console.WriteLine(string.Format("\n\tLa suma de {0} y {1} es {2}", num1, num2, num1 + num2));
            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadKey();
        }
    }
}


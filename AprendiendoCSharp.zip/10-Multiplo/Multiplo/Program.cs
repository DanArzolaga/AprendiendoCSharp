﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplo
{  //Nombre: Daniela Arzola García
   //Matricula: 1842239
   //Grupo: 32
   //Fecha: 28 de septiembre del 2019
    class Program
    {/*Elabore un proyecto llamado Multiplo, que pregunte un número entero.
        Si el número es múltiplo de 3 y múltiplo de 5, o múltiplo de 7, muestra el mensaje “Correcto”, de lo contrario,
        “Incorrecto”. Tip: Si un número es múltiplo de otro, residual es cero. */
        static void Main(string[] args)
        {//ENTRADA

            //Declaración de variables
            string _numero;
            int numero;
            bool esMultiplo3, esMultiplo5, esMultiplo7;
            
            //PROCESO
            try
            {
                Console.Write("\n\tDame un número entero: ");
                _numero = Console.ReadLine();
                numero = Convert.ToInt32(_numero);
                /*El multiplo de un numero es cuando el numero tiene un residual de cero con respecto
                a x numero.*/
                esMultiplo3 = ((numero % 3) == 0);
                esMultiplo5 = ((numero % 5) == 0);
                esMultiplo7 = ((numero % 7) == 7);

                //Si el multiplo de 3 y 5 al mismo tiempo no da 0,
                // O si es multiplo de 7  es correcto.
                if ((esMultiplo3 & esMultiplo7 || esMultiplo7))
                {
                    Console.WriteLine("\n\tCorrecto.");
                }

                else
                {//si no se cumple con la condicion es Incorreccto
                    Console.WriteLine("\n\tIncorrecto.");
                }
            }
            catch (Exception e)
            {//esto es por si se identifican errores

                Console.WriteLine("\n\tEl dato proporcionado causa errores. ");
                Console.WriteLine(e.Message);
            }
            finally
            {
                //SALIDA
                Console.WriteLine("\n\tPresiona cualquier tecla para terminar");
                Console.ReadKey();
            }
        }
    }
}

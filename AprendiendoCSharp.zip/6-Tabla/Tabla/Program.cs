﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabla
{
    /*Elabore un proyecto llamado Tabla, que pregunte un número entero del 1 al 9,
     * y muestre la tabla de multiplicar del número proporcionado.  */
    class Program
    {
        //Nombre: Daniela Arzola García
        //Matricula: 1842239
        //Grupo: 32
        //Fecha: 28 de septiembre del 2019
        static void Main(string[] args)
        {
            //Declaración de variables
            string num;
            int numero;
          
            //Entrada de datos
            Console.Write("Introduzca un Numero");
            num = Console.ReadLine();
            numero = Convert.ToInt32(num);

            //Se crea el ciclo con For, que nos permite hacer el ciclo de  una tabla de multiplicaciones

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(
                string.Format("{0} x {1} = {2}",
                numero, i, numero * 1));
            }

            //Salida
            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nombre
{   //Nombre: Daniela Arzola García
    //Matricula: 1842239
    //Grupo: 32
    //Fecha: 28 de septiembre del 2019
    class Program
    {
        static void Main(string[] args)
        /*Elabore un proyecto llamado Nombre, que pregunte dos datos: nombre, y apellido. 
         * Los debe transformar a mayúsculas, y mostrar en forma de nombre completo (concatenación). 
         * La concatenación debe ser eficiente, por lo que no se puede usar +.*/

        {//Declaramos variables
            string nombre;
            string apellido;
            Console.Write("\n\tEscribe un Nombre: ");
            nombre = Console.ReadLine();
            Console.Write("\n\tEscribe un Apellido: ");
            apellido = Console.ReadLine();

            //Convertimos el texto a Mayúsculas

            nombre.ToUpper();
            apellido.ToUpper();

            /*Los datos string son inmutables, por tanto
             * usamos StringBuilder y concatenamos sin repetir valores*/
            StringBuilder nombreCompleto = new StringBuilder(nombre);
            nombreCompleto.Append(" ");
            nombreCompleto.Append(apellido);

            //Salida
            Console.WriteLine("\n\tNombre Completo: " + nombreCompleto);
            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadKey();
        }
    }
}

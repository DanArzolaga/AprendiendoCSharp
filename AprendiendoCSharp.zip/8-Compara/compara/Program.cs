﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace compara
{   //Autor: Daniela Arzola García
    //Matricula: 1842239
    //Fecha: 20 de septiembre del 2019
    class Program
    {
        static void Main(string[] args)
        {/*Elabore un proyecto llamado Compara, que pregunte dos números, y que muestre cuál de los dos es mayor, 
            el primero o el segundo. También debe reportar si son iguales. 
            El mensaje debe decir: “Números proporcionados: x y y.
            El mayor es primero.” (o el segundo, o son iguales, según sea el caso).*/

            //ENTRADA
            //Declaracion de variables
            int num1 = 0;
            int num2 = 0;

            //Entrada de datos
            
            Console.WriteLine("\n\tIntroduzca el primer numero:");
            num1= int.Parse(Console.ReadLine());

            Console.WriteLine("\n\tIntroduzca el segundo numero:");
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("\n\tLos numeros proporcionados son: {0} y {1}", num1, num2);

            //PROCESO
            //Aqui hacemos uso del If que es un condicional en el que nos permite hacer 
            //diversos procesos si se cumple con la condicion que se establece
            if (num1>num2)
            {   //verifica si el primer numero es el mayor
                Console.WriteLine("\n\tEl Primer numero es el mayor");
            }
            if (num2>num1)
            {//verifica si el segundo numero es el mayor
                Console.WriteLine("\n\tEl segundo numero es el mayor");
            }
            if (num1==num2)
            {//verifica si los dos numeros son iguales 
                Console.WriteLine("\n\tLos numeros son iguales");
            }

            //SALIDA
            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadKey();
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acumulado
{ //Nombre: Daniela Arzola García
  //Matricula: 1842239
  //Grupo: 32
  //Fecha: 28 de septiembre del 2019
    class Program
    {/*Elabore un proyecto llamado Acumulado, que pregunte números enteros indefinidamente. 
        Sólo debe permitir números enteros, y notifica si no es así. Cada número que pregunte, deberá acumularlo, 
        mostrando “Acumulado hasta el momento: x”. El programa no deja de preguntar números y acumularlos,
        hasta que se deje vacía la entrada.  */
        static void Main(string[] args)
        {
            string Numeros;
            int numero;
            int acumulado = 0;
            Console.WriteLine("capture los enteros a acumular: ");
            Console.WriteLine("dejar vacio y dar INTRO para salir");
            Console.WriteLine("");

             //Entrada de datos 
             //Aqui se hace uso de un buqle condicional, no no ejecuta hast que se cumpla con la condición
            while (true)
            {
                Console.Write("\n\tIntroduzca un Número entero: ");
                Numeros = Console.ReadLine();
                if (Numeros == "")
                {
                    break;
                }
                else
                {
                    if (int.TryParse(Numeros, out numero))
                    {
                        acumulado += numero;
                        Console.WriteLine(String.Format("\n\tMonto acumulado: {0}", acumulado));
                    }
                    else
                    {
                        Console.WriteLine("\n\tEl dato proporcionado no es un Número entero");
                        Console.WriteLine("\n\tIntentelo de Nuevo");
                    }
                }

            }
            
            //Salida
            Console.WriteLine("\n\tPresione cualquier tecla para terminar...");
            Console.ReadKey();

        }
    }
}

